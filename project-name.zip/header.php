<!DOCTYPE html>
<html <?= language_attributes(); ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <? wp_head(); ?>
</head>