<?php
/**
 * Project Name Theme functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package project-name
 */

add_action( 'wp_enqueue_scripts', 'twentyfour_parent_parent_theme_enqueue_styles' );

/**
 * Enqueue scripts and styles.
 */
function twentyfour_parent_parent_theme_enqueue_styles() {
	wp_enqueue_style( 'twentyfour-parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'project-name-style',
		get_stylesheet_directory_uri() . '/style.css',
		[ 'twentyfour-parent-style' ]
	);
}


require_once dirname( __FILE__ ) . '/inc/enqueues/backend/styles.php';
require_once dirname( __FILE__ ) . '/inc/enqueues/backend/scripts.php';
require_once dirname( __FILE__ ) . '/inc/enqueues/frontend/styles.php';
require_once dirname( __FILE__ ) . '/inc/enqueues/frontend/scripts.php';