<?php
/**
 * Register and load any scripts your themes frontend requires.
 * !!!!! Remember to add the forth parameter to true so the link will be added in the footer!!!!!
 * Remember to use the min file when you go live with the project
 */

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script( 'bootstrap-5-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js', array(), null, true );
    wp_enqueue_script( 'frontend-js-parent', "http://localhost:8888/wp-content/themes/twentyfour-parent/js/frontend.js", array('jquery'), null, true );
    wp_enqueue_script( 'frontend-js', "http://localhost:8888/wp-content/themes/dist/js/frontend.js", array('jquery'), null, true );

    // We add the admin url into a variable and into the frontend-js file
    //Use "AjaxMethodsUrl" as link in do_ajax method
    //eg: do_ajax(AjaxMethodsUrl, data, callback);
    wp_localize_script( 'frontend-js', 'RootUrl', array( 'url' => get_stylesheet_directory_uri()) );
    wp_localize_script( 'frontend-js', 'AjaxMethodsUrl',  [admin_url( 'admin-ajax.php' )] );
});